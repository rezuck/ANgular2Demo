﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace tcgWebApp2.Model
{
    public class Detail
    {
        public int Id { get; set; }

        public string detailType { get; set; }
        public string detailSubtype { get; set; }
        public string detaildesc { get; set; }
        public string detailImgLoc { get; set; }
    }
}
