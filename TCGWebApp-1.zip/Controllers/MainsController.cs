using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using tcgWebApp2.Model;

namespace tcgWebApp2.Controllers
{
    [Route("api/[controller]")]
    public class MainsController : Controller
    {
        private readonly TCGDataContext _context;

        public MainsController(TCGDataContext context)
        {
            _context = context;    
        }

        // GET: Mains
        public async Task<IActionResult> Index()
        {
            return View(await _context.Mains.ToListAsync());
        }

        // GET: Mains/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var main = await _context.Mains
                .SingleOrDefaultAsync(m => m.Id == id);
            if (main == null)
            {
                return NotFound();
            }

            return View(main);
        }

        // GET: Mains/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Mains/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,oclass,otype,subtype,label,description,detailID")] Main main)
        {
            if (ModelState.IsValid)
            {
                _context.Add(main);
                await _context.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return View(main);
        }

        // GET: Mains/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var main = await _context.Mains.SingleOrDefaultAsync(m => m.Id == id);
            if (main == null)
            {
                return NotFound();
            }
            return View(main);
        }

        // POST: Mains/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,oclass,otype,subtype,label,description,detailID")] Main main)
        {
            if (id != main.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(main);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!MainExists(main.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction("Index");
            }
            return View(main);
        }

        // GET: Mains/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var main = await _context.Mains
                .SingleOrDefaultAsync(m => m.Id == id);
            if (main == null)
            {
                return NotFound();
            }

            return View(main);
        }

        // POST: Mains/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var main = await _context.Mains.SingleOrDefaultAsync(m => m.Id == id);
            _context.Mains.Remove(main);
            await _context.SaveChangesAsync();
            return RedirectToAction("Index");
        }

        private bool MainExists(int id)
        {
            return _context.Mains.Any(e => e.Id == id);
        }
    }
}
