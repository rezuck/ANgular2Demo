using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace tcgWebApp2.Controllers
{
    [Route("api/[controller]")]
    public class PeopleController : Controller
    {
        private static string[] Names = new[]
        {
            "Albert Einstein", "John von Neumann", "Sam Spade", "Richard Feynman", "Isaac Newton", "Sophus Lie", "Hercule Poirrot"
        };

        private static string[] Professions = new[]
        {
            "Mathematician", "Physicist", "Detective", "Scientist", "Doctor", "Big Mucky Muck", "Biologist", "Statistician", "Chemist", "Truck Driver"
        };

        private static string[] Location = new[]
        {
            "Princeton", "London", "San Francisco", "Bruxelles", "Berlin", "Vienna", "Paris"
        };

        private static string[] Contacts = new[]
        {
            "(111)222-3333", "(222)333-4444", "(333)444-5555", "(444)555-6666", "(555)666-7777", "(666)777-8888", "(777)888-9999"
        };

        private static string[] Photos = new[]
        {
            "/dist/Poirot.png", "/dist/SAMSpade.png", "/dist/JohnvonNeumann-LosAlamos.gif", "/dist/feynman632.jpg", "/dist/80619-004-9B9D0D26.jpg", "/dist/80619-004-9B9D0D26.jpg", "/dist/"
        };

        private static string[] Thrm = new[]
        {
            "Law of Gravity", "General Relativity", "Game Theory", "Who murdered John Doe", "Path Integrals"
        };

        [HttpGet("[action]")]
        public IEnumerable<Person> PersonList()
        {
            var rng = new Random();
            List<Person> output = new List<Person>();

            for (int i = 0; i < 4; i++)
            {
                Person per = new Person();
                per.Id = i;
                per.Name = Names[rng.Next(Names.Length)];
                per.Profession = Professions[rng.Next(Professions.Length)];
                per.Location = Location[rng.Next(0, 4)];
                per.Contact = Contacts[rng.Next(0, 4)];
                per.Theory = Thrm[rng.Next(0, 4)];
                per.Picture = Photos[rng.Next(0, 5)];

                output.Add(per);
            };

            return output;
        }
        //rng.Next(Professions.Length)
        //rng.Next(0, 4)
        public class Person
        {
            public int Id { get; set; }
            public string Name { get; set; }
            public string Profession { get; set; }
            public string Location { get; set; }
            public string Contact { get; set; }
            public string Theory { get; set; }
            public string Picture { get; set; }

        }
    }
}