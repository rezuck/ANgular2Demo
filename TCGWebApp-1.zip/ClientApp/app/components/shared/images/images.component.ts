﻿import { Component } from '@angular/core';

@Component({
    selector: 'shared-images',
    templateUrl: './images.component.html',
    styleUrls: ['./images.component.css']

})
export class ImagesComponent {
    name: string;
    caption: string;

    constructor() {
        this.name = 'The CyberGroup, Inc.';
        this.caption = 'Some Images';
    }
}
