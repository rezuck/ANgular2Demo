﻿import { Component, Input } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/Operator'

@Component({
    selector: 'select-topics',
    templateUrl: './topics.component.html'
})

export class TopicsComponent {
    public items: topic[];
    public topics: topic[];
    
    constructor(http: Http) {

        this.topics = [
            { name: 'Literature' , value: 'Literature'},
            { name: 'Mathematics', value: 'Mathematics' },
            { name: 'Physics', value: 'Physics' },
            { name: 'Quantum Mechanics', value: 'Quantum Mechanics' }];
    }

    actionEvent(itm: topic): void {
        //todo: This is a stub
        alert("You selected " + itm.value);
    }

    @Input() newtopic: string;

}


interface topic {
    name: string;
    value: string;
}
