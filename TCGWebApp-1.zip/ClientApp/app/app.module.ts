import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { UniversalModule } from 'angular2-universal';
import { AppComponent } from './components/app/app.component'
import { NavMenuComponent } from './components/navmenu/navmenu.component';
import { HomeComponent } from './components/home/home.component';
import { FetchDataComponent } from './components/fetchdata/fetchdata.component';
import { CounterComponent } from './components/counter/counter.component';
import { HeaderComponent } from './components/shared/header/header.component';
import { ImagesComponent } from './components/shared/images/images.component';
import { InfoComponent } from './components/info/info.component';
import { BooksComponent } from './components/books/books.component';
import { ItemListComponent } from './components/itemlist/itemlist.component';
import { PeopleComponent } from './components/people/people.component';
import { TopicsComponent } from './components/topics/topics.component';

@NgModule({
    bootstrap: [AppComponent],
    declarations: [
        AppComponent,
        NavMenuComponent,
        CounterComponent,
        FetchDataComponent,
        HeaderComponent,
        ImagesComponent,
        InfoComponent,
        BooksComponent,
        TopicsComponent,
        ItemListComponent,
        PeopleComponent,
        HomeComponent
    ],
    imports: [
        UniversalModule, // Must be first import. This automatically imports BrowserModule, HttpModule, and JsonpModule too.
        FormsModule,
        RouterModule.forRoot([
            { path: '', redirectTo: 'home', pathMatch: 'full' },
            { path: 'home', component: HomeComponent },
            { path: 'info', component: InfoComponent },
            { path: 'itemlist', component: ItemListComponent },
            { path: 'people', component: PeopleComponent },
            { path: 'books', component: BooksComponent },
            { path: 'topics', component: TopicsComponent },
            { path: 'counter', component: CounterComponent },
            { path: 'fetch-data', component: FetchDataComponent }
        ])
    ]
})
export class AppModule {
}
