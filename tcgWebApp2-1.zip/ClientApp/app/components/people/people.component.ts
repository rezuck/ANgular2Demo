﻿import { Component } from '@angular/core';
import { Http } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/Operator'

@Component({
    selector: 'people',
    templateUrl: './people.component.html',
    styleUrls: ['./people.component.css']
})

export class PeopleComponent {
    public message: string;
    public itemval: string;
    public persons: person[];
    public editid: number;
    public editname: string;
    public editprofession: string;
    public editlocation: string;
    public editcontact: string;
    public edittheory: string;
    public editpicture: string;

   constructor(http: Http) {
       this.itemval = "...getting data - please wait"
       //this.message = "...fetching data"
       http.get('/api/People/PersonList').subscribe(result => {
           this.persons = result.json() as person[];
       });
       this.itemval = "success";
    }

   editperson(cont: person) {
       this.editname = cont.name;
       this.editprofession = cont.profession;
       this.editlocation = cont.location;
       this.editcontact = cont.contact;
       this.edittheory = cont.theory;
       this.editpicture = cont.picture;
       var edp = document.getElementById("disp").style.display = "none";
       var edp2 = document.getElementById("pdtl").style.display = "";
   }

   closeEdit(){
       var edd = document.getElementById("disp").style.display = "";
       var edd2 = document.getElementById("pdtl").style.display = "none";
   }
}

interface person {
    id: number;
    name: string;
    profession: string;
    location: string;
    contact: string;
    theory: string;
    picture: string;
}
