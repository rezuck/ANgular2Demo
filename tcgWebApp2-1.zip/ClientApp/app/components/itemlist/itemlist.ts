﻿interface itemList {
    ID: number;
    oClass: string;
    oType: string;
    subType: string;
    oDesc: string;
    imgUrl: string;
}
