﻿import { Component, Pipe, PipeTransform } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/Operator';
//This is the data class 'itemList'. Since we may want to use this in different circumstances its
//better to have a separate file.
import './itemlist';

@Component({
    selector: 'itemlist',
    templateUrl: './itemlist.component.html',
    styleUrls: ['./itemlist.component.css']
})

export class ItemListComponent {
    public items: itemList[];
    //public items: ListItems[];
    preval: string;
    retval: string;
    imageurl: string;
    imageurl2: string;
    imageurl3: string;
 
    constructor(http: Http) {
        this.preval = "starting..."
        this.imageurl = "../app/pics/AA923Dy.jpg"
        this.imageurl2 = "../ClientApp/pics/AA923Dy.jpg"
        this.imageurl3 = "../ClientApp/dist/e2fb0cea29f5b569bd4a4b9255fe517a.jpg"

        //Notice that we are using an Observable

        http.get('/api/Data/GetList').subscribe(result => {
            this.items = result.json() as itemList[];
        });

        //http.get('/api/Data/GetList').subscribe(result => {
        //    this.items = result.json() as ListItems[];
        //});

        this.retval = "success";
        //http.get('api/Data/Get')
        //    .subscribe(result => { this.items.push(result.json() as itemList); });
    }

    private extractData(res: Response) {
        let body = res.json();
        return body.data || {};
    }

    sortbySubType2() {
        this.items.sort();
    }

    sortbyClass() {
        this.items.sort(function (type1, type2) {
            if (type1.oClass < type2.oClass) {
                return -1;
            }
            else if (type1.oClass > type2.oClass) {
                return 1;
            }
            else {
                return 0;
            }
        });
    }

    sortbySubType() {
        this.items.sort(function (type1, type2) {
            if (type1.subType < type2.subType) {
                return -1;
            }
            else if (type1.subType > type2.subType) {
                return 1;
            }
            else {
                return 0;
            }
        });
    }

    sortbyType() {
        this.items.sort(function (type1, type2) {
            if (type1.oType < type2.oType) {
                return -1;
            }
            else if (type1.oType > type2.oType) {
                return 1;
            }
            else {
                return 0;
            }
        });
    }

    sortbyDesc() {
        this.items.sort(function (type1, type2) {
            if (type1.oDesc < type2.oDesc) {
                return -1;
            }
            else if (type1.oDesc > type2.oDesc) {
                return 1;
            }
            else {
                return 0;
            }
        });
    }

    private handleErr(error: Response | any)
    {
        this.preval = "An Error occurred";
    }
}

/*
interface itemList {
    ID: number;
    oClass: string;
    oType: string;
    subType: string;
    oDesc: string;
    imgUrl: string;
}
*/


