﻿interface spaceObjects {
    Id: number;
    classification: string;
    objectType: string;
    objectName: string;
    objectDescription: string;
    imgUrl: string;
}