﻿import { Component, Pipe, PipeTransform } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/Operator';
//This is the data class 'spaceObjects'. Since we may want to use this in different circumstances its
//better to have a separate file.
import './spaceobjs';
import { SpaceService } from './space.service';

@Component({
    selector: 'spacelist',
    templateUrl: './space.component.html',
    styleUrls: ['./space.component.css']
})

export class SpaceComponent {
    public spaceobjs: spaceObjects[];
   
    preval: string;
    retval: string;

    constructor(http: Http) {
        this.preval = "starting..."

        //Notice that we are using an Observable
        try {
            http.get('/api/Space/GetList').subscribe(result => {
               this.spaceobjs = result.json() as spaceObjects[];
            });

            //this.spaceobjs =
            //    [{ "Id": 0, "Classification": "Solar System", "ObjectType": "Planet", "ObjectName": "Jupiter", "ObjectDescription": "Full view of planet", "imgUrl": "/dist/com.jpg" },
            //    { "Id": 2, "Classification": "Galaxy", "ObjectType": "Nebula", "ObjectName": "Crab Nebula", "ObjectDescription": "Hubble image of nebula", "imgUrl": "/dist/com.jpg" }
            //    ];

            //this.spaceservice.getItemList()
            //    .subscribe(result => {this.spaceobjs = result.json() as spaceObjects[];
            //});

             this.preval = "-> tried"
           //this.preval = this.sv.getMsg().toString();
           // http.get('/api/Space/getMsg').subscribe(result => {
           //    this.preval = result.toString();
           // });


        }
        catch (err) {
            this.preval = "Error:" + err.message;
        }
        //http.get('/api/Data/GetList').subscribe(result => {
        //    this.items = result.json() as spaceObjects[];
        //});

        //this.retval = "success";
        //http.get('api/Data/Get')
        //    .subscribe(result => { this.items.push(result.json() as itemList); });
    }

    sortbySubType2() {
        this.spaceobjs.sort();
    }

    sortbyClass() {
        this.spaceobjs.sort(function (type1, type2) {
            if (type1.classification < type2.classification) {
                return -1;
            }
            else if (type1.classification > type2.classification) {
                return 1;
            }
            else {
                return 0;
            }
        });
    }

    sortbySubType() {
        this.spaceobjs.sort(function (type1, type2) {
            if (type1.objectName < type2.objectName) {
                return -1;
            }
            else if (type1.objectName > type2.objectName) {
                return 1;
            }
            else {
                return 0;
            }
        });
    }

    sortbyType() {
        this.spaceobjs.sort(function (type1, type2) {
            if (type1.objectType < type2.objectType) {
                return -1;
            }
            else if (type1.objectType > type2.objectType) {
                return 1;
            }
            else {
                return 0;
            }
        });
    }

    sortbyDesc() {
        this.spaceobjs.sort(function (type1, type2) {
            if (type1.objectDescription < type2.objectDescription) {
                return -1;
            }
            else if (type1.objectDescription > type2.objectDescription) {
                return 1;
            }
            else {
                return 0;
            }
        });
    }
}


