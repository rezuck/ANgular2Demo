﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace tcgWebApp2.Model
{
    public class SpaceObj
    {
            public int Id { get; set; }

            public string Classification { get; set; }
            public string ObjectType { get; set; }
            public string ObjectName { get; set; }
            public string ObjectDescription { get; set; }
            public string imgUrl { get; set; }
    }
}
