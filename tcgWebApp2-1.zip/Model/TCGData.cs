﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace tcgWebApp2.Model
{
    public class TCGDataContext : DbContext
    {
        public DbSet<mainTable> mainTables { get; set; }
        public DbSet<Main> Mains { get; set; }
        public DbSet<Detail> Details { get; set; }
        public DbSet<SpaceObj> SpaceObjects { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Server=TCGLAPTOP\SQLEXPRESS;Database=TCGBase;Trusted_Connection=True;");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<mainTable>().ToTable("mainTable");
            modelBuilder.Entity<Main>().ToTable("Main");
            modelBuilder.Entity<Detail>().ToTable("Detail");
            modelBuilder.Entity<SpaceObj>().ToTable("SpaceObject");
            modelBuilder.Entity<mainTable>().HasKey(m => m.recordID);
            modelBuilder.Entity<SpaceObj>().HasKey(s => s.Id);
        }
    }
}
