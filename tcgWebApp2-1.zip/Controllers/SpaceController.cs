using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using tcgWebApp2.Model;

namespace tcgWebApp2.Controllers
{
    [Route("api/[controller]")]
    public class SpaceController : Controller
    {
        private readonly TCGDataContext _context;
        private string errmsg = "";

        public SpaceController(TCGDataContext context)
        {
            _context = context;
        }

        // GET: api/getMsg
        [HttpGet("[action]")]
        public IEnumerable<string> getMsg()
        {
            return new string[] { "Returned from Space Controller" };
        }

        // GET: api/GetList
        [HttpGet("[action]")]
        public IEnumerable<SpaceObj> GetList()
        {
            List<SpaceObj> olist = new List<SpaceObj>();
            List<tcgWebApp2.Model.SpaceObj> items;
            Console.Write("... in Space Controller");

            //items = _context.dbMain.ToList<tcgWebApp2.Model.mainTable>();
            try
            {
                items = _context.SpaceObjects.ToList();
                foreach (tcgWebApp2.Model.SpaceObj m in items)
                {
                    var ol = new SpaceObj();
                    ol.Id = m.Id;
                    ol.Classification = m.Classification;
                    ol.ObjectType = m.ObjectType;
                    ol.ObjectName = m.ObjectName;
                    ol.ObjectDescription = m.ObjectDescription;
                    ol.imgUrl = m.imgUrl;

                    olist.Add(ol);
                }
            }
            catch (Exception e)
            {
                errmsg = e.Message;
            }
            return olist;
        }
    }
}