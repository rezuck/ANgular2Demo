using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace tcgWebApp2.Controllers
{
    [Route("api/[controller]")]
    public class PeopleController : Controller
    {
        private static string[] Person = new[]
        {
            "Albert Einstein", "John von Neumann", "Sam Spade", "Richard Feynman", "Isaac Newton", "Sophus Lie", "Hercule Poirrot"
        };

        private static string[] Professions = new[]
        {
            "Mathematician", "Physicist", "Detective", "Scientist", "Doctor", "Big Mucky Muck", "Biologist", "Statistician", "Chemist", "Truck Driver"
        };

        private static string[] Location = new[]
        {
            "Princeton", "London", "San Francisco", "Bruxelles", "Berlin", "Vienna", "Paris"
        };

        private static string[] Contacts = new[]
        {
            "(111)222-3333", "(222)333-4444", "(333)444-5555", "(444)555-6666", "(555)666-7777", "(666)777-8888", "(777)888-9999"
        };

        [HttpGet("[action]")]
        public IEnumerable<Personnel> Persons()
        {
            var rng = new Random();
            var output = Enumerable.Range(1, 5).Select(index => new Personnel
            {
                Name = Person[index],
                Profession = Professions[rng.Next(Professions.Length)],
                Location = Location[rng.Next(0, 4)],
                Contact = Contacts[rng.Next(0, 4)]
            });

            return output;
        }

        public class Personnel
        {
            public string Name { get; set; }
            public string Profession { get; set; }
            public string Location { get; set; }
            public string Contact { get; set; }

        }
    }
}