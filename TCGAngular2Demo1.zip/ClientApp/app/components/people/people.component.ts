﻿import { Component } from '@angular/core';
import { Http } from '@angular/http';

@Component({
    selector: 'people',
    templateUrl: './people.component.html'
})
export class PeopleComponent {
    public persons: person[];

    constructor(http: Http) {
        http.get('/api/People/Persons').subscribe(result => {
            this.persons = result.json() as person[];
        });
    }
}

interface person {
    Name: string;
    Profession: string;
    Location: string;
    Contact: string;
}
