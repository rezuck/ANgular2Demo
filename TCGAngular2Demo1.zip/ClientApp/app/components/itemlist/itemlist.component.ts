﻿import { Component } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/Operator'

@Component({
    selector: 'itemlist',
    templateUrl: './itemlist.component.html'
})

export class ItemListComponent {
    public items: itemList[];
    preval: string;
    retval: string;
    imageurl: string;
    imageurl2: string;
    imageurl3: string;
 
    constructor(http: Http) {
        this.preval = "starting..."
        this.imageurl = "../app/pics/AA923Dy.jpg"
        this.imageurl2 = "../ClientApp/pics/AA923Dy.jpg"
        this.imageurl3 = "../ClientApp/dist/e2fb0cea29f5b569bd4a4b9255fe517a.jpg"

        http.get('/api/Data/GetList').subscribe(result => {
            this.items = result.json() as itemList[];
        });
        this.retval = "success";
        //http.get('api/Data/Get')
        //    .subscribe(result => { this.items.push(result.json() as itemList); });
     }

    private extractData(res: Response) {
        let body = res.json();
        return body.data || {};
    }

    private handleErr(error: Response | any)
    {
        this.preval = "An Error occurred";
    }
}

interface itemList {
    ID: number;
    oClass: string;
    oType: string;
    subtype: string;
    oDesc: string;
    imgUrl: string;
}
