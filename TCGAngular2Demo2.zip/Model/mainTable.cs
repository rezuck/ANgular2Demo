﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace tcgWebApp2.Model
{
    public class mainTable
    {
        public int recordID { get; set; }

        public string typeclass { get; set; }
        public string classsub { get; set; }
        public string subtype { get; set; }
        public string shortdesc { get; set; }
        public string description { get; set; }
        public string imgurl { get; set; }
        public int? detailID { get; set; }
    }
}
