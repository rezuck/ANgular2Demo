﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using tcgWebApp2.Model;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace tcgWebApp2.Controllers
{
    [Route("api/[controller]")]
    public class TCGDataController : Controller
    {
        private readonly TCGDataContext _context;

        public TCGDataController(TCGDataContext context)
        {
            context = new TCGDataContext();
            _context = context;
        }

        // GET: /<controller>/
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet("[action]")]
        public IEnumerable<ItemList> Get()
        {
            List<ItemList> olist = new List<ItemList>(); 
            List<tcgWebApp2.Model.Main> items;
            items = _context.Mains.ToList<tcgWebApp2.Model.Main>();
            foreach(tcgWebApp2.Model.Main m in items)
            {
                var ol = new ItemList();
                ol.ID = m.Id;
                ol.oClass = m.oclass;
                ol.oType = m.otype;
                ol.subType = m.subtype;
                ol.oDesc = m.description;
                ol.imgUrl = m.label;

                olist.Add(ol);
            }
            return olist;
        }

        private static string[] Summaries = new[]
{
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };

        [HttpGet("[action]")]
        public IEnumerable<ItemList> ListItems()
        {
            var rng = new Random();
            return Enumerable.Range(1, 5).Select(index => new ItemList
            {
                oClass = "Classtype",
                oType = "Some type",
                subType = "A subtype",
                oDesc = "a Description"
            });
        }

    }
    public class ItemList
    {
        public int ID { get; set; }
        public string oClass { get; set; }
        public string oType { get; set; }
        public string subType { get; set; }
        public string oDesc { get; set; }
        public string shortDesc { get; set; }
        public string imgUrl { get; set; }
    }



}
