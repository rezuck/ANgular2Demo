﻿import { Component } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/Operator'

@Component({
    selector: 'books',
    templateUrl: './books.component.html'
})

export class BooksComponent {
    public booklist: books[];
    public preval: string;
    public retval: string;

    constructor(http: Http) {

        this.preval = "...getting data";
        http.get('/api/Books/BookList').subscribe(result => {
            this.booklist = result.json() as books[];
        });
        this.retval = "success";
        //http.get('api/Data/Get')
        //    .subscribe(result => { this.items.push(result.json() as itemList); });
    }

}

interface books {
    author: string;
    title: string;
    topic: string;
    pubdate: string;
}
