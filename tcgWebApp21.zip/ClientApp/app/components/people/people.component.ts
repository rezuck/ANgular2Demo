﻿import { Component } from '@angular/core';
import { Http } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/Operator'

@Component({
    selector: 'people',
    templateUrl: './people.component.html'
})

export class PeopleComponent {
    public message: string;
    public item: string;
    public persons: person[];

   constructor(http: Http) {
       this.item = "...getting data - please wait"
       //this.message = "...fetching data"
       http.get('/api/People/PersonList').subscribe(result => {
           this.persons = result.json() as person[];
       });
       this.item = "success";
    }
}

interface person {
    name: string;
    profession: string;
    location: string;
    contact: string;
}
