﻿import { Component } from '@angular/core';

@Component({
    selector: 'info',
    templateUrl: './info.component.html',
    styleUrls: ['./info.component.css']

})
export class InfoComponent {
    name: string;
    caption: string;

    constructor() {
        this.name = 'The CyberGroup, Inc.';
        this.caption = 'Some Information';
    }

}

interface ItemList {
    ID: number;
    oclass: string;
    otype: string;
    subtype: string;
    description: string;
    imgurl; string;
}