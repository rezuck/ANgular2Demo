﻿import { Component } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/Operator'

@Component({
    selector: 'books',
    templateUrl: './books.component.html'
})

export class BooksComponent {
    public booklist: books[];
    public prevval: string;
    public retnval: string;
    public imgsrc: string;
    public viewid: string;
    public isActive: string[];
    public isEditable: boolean;
    public editbook: editval;
    selectedBook: books;
    public auth: string;
    public newid: number;
    public newauthor: string;
    public newtitle: string;
    public newtopic: string;
    public newpubdate: string;
    newbk: books;

    constructor(http: Http) {

        this.prevval = "...getting data";
        this.imgsrc = "../../../../Content/Images/AA8MJrW.jpg";
        this.viewid = "grid";
        this.isEditable = false;
        this.auth = "none";
        this.newauthor = "";
        this.newtitle = "";
        this.newtopic = "";
        this.newpubdate = "";

        http.get('/api/Books/BookList').subscribe(result => {
            this.booklist = result.json() as books[];
        });

        this.retnval = "success";
    }

    clickimage() {
        //event.preventDefault();
        this.imgsrc = "../../../../Content/Images/m1_hst_900.jpg";
        this.retnval = "...fetched image";
        alert("in event.. url = " + this.imgsrc);

    }

    showrow(id: number) {
        var ed = document.getElementById("itm" + id).style.display = "none";
        var ed2 = document.getElementById("bk" + id).style.display = "";
    }

    Selected(book: books): void {
        this.selectedBook = book;
        this.auth = book.author;
        this.isEditable = !this.isEditable;
        var ed = document.getElementById("itm" + book.id).style.display = "";
        var ed2 = document.getElementById("bk" + book.id).style.display = "none";
    }

    CancelEdit(book: books): void {
        book.author = this.booklist[book.id].author;
        book.title = this.booklist[book.id].title;
        book.topic = this.booklist[book.id].topic;
        book.pubdate = this.booklist[book.id].pubdate;
        var ed = document.getElementById("itm" + book.id).style.display = "";
        var ed2 = document.getElementById("bk" + book.id).style.display = "none";
    }

    SaveNew(): void {
        if (this.newauthor.length > 0 && this.newtitle.length > 0 && this.newtopic.length > 0) {
            this.booklist.push({
                "id": this.booklist.length,
                "author": this.newauthor,
                "title": this.newtitle,
                "topic": this.newtopic,
                "pubdate": this.newpubdate
            });

            this.retnval = "Added: " + this.booklist[this.booklist.length].title;
        }
        else
        {
            this.retnval = "Data missing";
        }

    }

    onSubmit(): void {
        //todo: This is a stub
    }

}

interface books {
    id: number;
    author: string;
    title: string;
    topic: string;
    pubdate: string;
}

interface editval {
    id: number;
    key: string;
    value: boolean;
}
