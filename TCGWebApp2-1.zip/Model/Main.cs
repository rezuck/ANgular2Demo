﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace tcgWebApp2.Model
{
    public class Main
    {
        public int Id { get; set; }

        public string oclass { get; set; }
        public string otype { get; set; }
        public string subtype { get; set; }
        public string label { get; set; }
        public string description { get; set; }
        public int detailID { get; set; }
    }
}
