﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using tcgWebApp2.Model;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace tcgWebApp2.Controllers
{
    [Route("api/[controller]")]
    public class DataController : Controller
    {
        //private readonly TCGDataContext _context;
        private readonly TCGDataContext _context;

        public DataController(TCGDataContext context)
        {
            _context = context;
        }

        // GET: api/values
        [HttpGet("[action]")]
        public IEnumerable<string> xGet()
        {
            return new string[] { "value1" };
        }

        // GET: api/values
        [HttpGet("[action]")]
        public IEnumerable<ItemList> GetItems()
        {
            List<ItemList> oList = new List<ItemList>();
            Console.Write("in DataController");
            for ( int i = 0; i <= 4; i++)
            {
                var il = new ItemList();
                il.ID = i;
                il.oClass = "first";
                il.oType = "Type" + i.ToString();
                il.subType = "sub_" + i.ToString();
                il.shortDesc = "short Desc of " + i.ToString();
                il.oDesc = "Item number " + i.ToString();
                il.imgUrl = "url:";
                oList.Add(il);

            }
            return oList;
        }

        [HttpGet("[action]")]
        public IEnumerable<ItemList> GetList()
        {
            List<ItemList> olist = new List<ItemList>();
            List<tcgWebApp2.Model.mainTable> items;
      
            //items = _context.dbMain.ToList<tcgWebApp2.Model.mainTable>();

            items = _context.mainTables.ToList();
            foreach (tcgWebApp2.Model.mainTable m in items)
            {
                var ol = new ItemList();
                ol.ID = m.recordID;
                ol.oClass = m.typeclass;
                ol.oType = m.classsub;
                ol.subType = m.subtype;
                ol.shortDesc = m.shortdesc;
                ol.oDesc = m.description;
                ol.imgUrl = m.imgurl;

                olist.Add(ol);
            }
            return olist;
        }


        // GET api/values/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // POST api/values
        [HttpPost]
        public void Post([FromBody]string value)
        {
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
