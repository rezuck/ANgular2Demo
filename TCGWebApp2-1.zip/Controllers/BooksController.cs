using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace tcgWebApp2.Controllers
{
    [Route("api/[controller]")]
    public class BooksController : Controller
    {

        [HttpGet("[action]")]
        public IEnumerable<book> BookList()
        {
            List<book> output = new List<book>();
            var bk = new book();
            bk.Id = 0;
            bk.author = "B. DeWit";
            bk.title = "The Many Worlds Interpretation of Quantum Mechanics";
            bk.topic = "Quantum Mechanics";
            bk.pubdate = "1967";

            output.Add(bk);

            var bk1 = new book();
            bk1.Id = 1;
            bk1.author = "Max Jammer";
            bk1.title = "The Philosophy of Quantum Mechanics";
            bk1.topic = "Quantum Mechanics";
            bk1.pubdate = "1974";

            output.Add(bk1);

            var bk2 = new book();
            bk2.Id = 2;
            bk2.author = "I. Vaisman";
            bk2.title = "The Geometry of Poisson Manifolds";
            bk2.topic = "Mathematics";
            bk2.pubdate = "1986";

            output.Add(bk2);

            return output;
        }

        public class book
        {
            public int Id { get; set; }
            public string author { get; set; }
            public string title { get; set; }
            public string topic { get; set; }
            public string pubdate { get; set; }
        }
    }
}